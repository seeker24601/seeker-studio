# Install AI Connections into a project

This release includes a local CLI, provider runtime, React settings components, and a shared skill for Claude Code and Codex.
The packages are on npm as `ai-connections`, `ai-connections-react` and `ai-connections-cli`.

## Install

From your application directory:

```sh
npm install ai-connections ai-connections-react
npm install --save-dev ai-connections-cli
npx --no-install ai-connections init --dry-run
npx --no-install ai-connections init
```

To try unreleased changes, build tarballs in an AI Connections checkout with `npm install && npm run build && npm run pack:all`, then install the three `.tgz` files it writes to `artifacts/` by absolute path in place of the package names.

The CLI needs Node.js 22 or later. It never installs dependencies or transmits project content.
Use `--cwd /path/to/project` to target another project.
Use `--agent claude` or `--agent codex` with `init` to install one skill. The default installs both.

## Product MCP server

The unreleased CLI includes `ai-connections mcp`. From a checkout, run:

```sh
node packages/cli/src/index.mjs mcp --cwd /path/to/product --dry-run
node packages/cli/src/index.mjs mcp --cwd /path/to/product
```

It creates `ai-connections/mcp/` with an isolated package, product action hooks,
stdio and HTTP servers, a verification script, and client configuration
examples for Claude, Codex, Cursor, and Hermes. It preserves existing files.
React is optional for this command. The generated `ai-connections/mcp/README.md`
covers host authentication and product action integration.

## What the installer creates

| Project | Generated integration |
| --- | --- |
| Next.js App Router | API catch-all route and settings page under the existing `app` or `src/app` directory |
| Other React projects, including Vite | Client component and portable Node handler examples under `ai-connections/` |

The CLI also creates `AI_CONNECTIONS.md`, a descriptive JSON config, and the selected agent skills.
The config records installation choices. It does not configure the runtime automatically.
The CLI adds missing variables to `.env.example` and the default data directory to `.gitignore`.
It preserves other existing files, including changes from previous installations.
A repeat run reports preserved files. It does not upgrade their contents.
Output paths containing symbolic links cause installation to fail before writes.

## Complete application wiring

The Next.js route rejects requests until the host supplies trusted server authentication.
Replace its `getOwnerId` callback with the application's server-verified session lookup.
React/Vite projects also need a Node server route. The generated server example accepts the same callback.

Create a 32-byte encryption key:

```sh
node -e "console.log(require('node:crypto').randomBytes(32).toString('base64'))"
```

Set `AI_CONNECTIONS_ENCRYPTION_KEY` through the server's secret configuration.
Set `AI_CONNECTIONS_DATA_DIR` to a private persistent directory.
Keep encryption keys stable and separate from encrypted records.
The included file store supports a single Node host. Ephemeral and multi-instance hosts need an application database adapter.

The component uses `ConnectionSettings` from `ai-connections-react` and the package's `styles.css` stylesheet.
Adapt its component slots and CSS variables to the existing interface.
Connect each AI feature to the configured core service and its selected connection.
An installed settings screen alone does not redirect existing provider calls.

Local endpoints refer to the server's network. Hosted applications need a separate path to reach users' local models.
Private endpoints require an explicit network policy appropriate for the host.

## Use with a coding agent

Claude Code receives `.claude/skills/ai-connections/SKILL.md`.
Codex receives `.agents/skills/ai-connections/SKILL.md`.
Both files contain the same workflow.

Ask the agent:

> Integrate AI Connections with our existing authentication, settings design, and AI features. Follow the installed ai-connections skill and verify it locally.

The agent must connect trusted authentication, adapt the UI, and verify actual application behavior.
Check credential redaction and owner isolation before using real credentials.
Live provider verification requires an authorized key and can incur usage charges.
