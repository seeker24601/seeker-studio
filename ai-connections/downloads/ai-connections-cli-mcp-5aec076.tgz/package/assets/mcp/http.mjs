import express from 'express';
import cors from 'cors';
import { hostHeaderValidation } from '@modelcontextprotocol/sdk/server/middleware/hostHeaderValidation.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { createServer, principalSchema } from './server.mjs';
import { authenticateHttp } from './access.mjs';
import { isEntry } from './entry.mjs';

export function createHttpApp({ host = '127.0.0.1', allowedHosts, allowedOrigins = [] } = {}) {
  if (!['127.0.0.1', 'localhost', '::1'].includes(host) && !allowedHosts?.length) {
    throw new Error('Configure allowedHosts before binding a public MCP server.');
  }
  const app = express();
  app.disable('x-powered-by');
  app.use(hostHeaderValidation(allowedHosts || ['127.0.0.1', 'localhost', '[::1]']));
  app.use('/mcp', (request, response, next) => {
    if (request.headers.origin && !allowedOrigins.includes(request.headers.origin)) {
      return response.status(403).json({ error: 'Origin is not permitted.' });
    }
    next();
  }, cors({
    origin: allowedOrigins, credentials: true, methods: ['POST'],
    exposedHeaders: ['Mcp-Session-Id', 'MCP-Protocol-Version', 'WWW-Authenticate'],
  }), async (request, response, next) => {
    try {
      const principal = principalSchema.safeParse(await authenticateHttp(request));
      if (!principal.success) return response.status(401).json({ error: 'Authentication required.' });
      response.locals.principal = principal.data;
      next();
    } catch {
      response.status(401).json({ error: 'Authentication required.' });
    }
  });
  app.use(express.json({ limit: '1mb' }));
  app.post('/mcp', async (request, response) => {
    let server;
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
    response.once('close', () => { void transport.close(); void server?.close(); });
    try {
      server = createServer(response.locals.principal);
      await server.connect(transport);
      await transport.handleRequest(request, response, request.body);
    } catch {
      if (!response.headersSent) response.status(500).json({ error: 'MCP request failed.' });
      await transport.close();
      await server?.close();
    }
  });
  app.all('/mcp', (_request, response) => { response.setHeader('Allow', 'POST'); response.status(405).end(); });
  app.use((error, _request, response, _next) => {
    const status = Number.isInteger(error.status) && error.status >= 400 && error.status < 500 ? error.status : 500;
    if (!response.headersSent) response.status(status).json({ error: 'Invalid MCP request.' });
  });
  return app;
}

if (await isEntry(process.argv[1], import.meta.url)) {
  const port = Number(process.env.PRODUCT_MCP_PORT ?? 4318);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('Invalid PRODUCT_MCP_PORT.');
  const listener = createHttpApp().listen(port, '127.0.0.1', () => {
    process.stderr.write(`MCP_HTTP_READY:http://127.0.0.1:${listener.address().port}/mcp\n`);
  });
}
