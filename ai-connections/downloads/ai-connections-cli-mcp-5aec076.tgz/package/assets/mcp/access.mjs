import { userInfo } from 'node:os';

export function localPrincipal() {
  return { ownerId: userInfo().username, permissions: ['product:read'] };
}

export async function authenticateHttp(request) {
  // Return { ownerId, permissions } from the product's verified server session.
  return null;
}

export async function authorize(principal, action) {
  return principal.permissions.includes(action.permission);
}
