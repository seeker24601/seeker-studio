import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { product, actions } from './actions.mjs';
import { authorize } from './access.mjs';

export const principalSchema = z.object({
  ownerId: z.string().min(1).max(512),
  permissions: z.array(z.string().min(1).max(128)).max(128),
}).strict();

const failure = message => ({ isError: true, content: [{ type: 'text', text: message }] });

export function createServer(identity) {
  const principal = principalSchema.parse(identity);
  const server = new McpServer(product);
  for (const action of actions) {
    if (!action.permission || !action.inputSchema || !action.outputSchema) {
      throw new Error('Product actions require a permission and input/output schemas.');
    }
    server.registerTool(action.name, {
      description: action.description, inputSchema: action.inputSchema,
      outputSchema: action.outputSchema, annotations: action.annotations,
    }, async args => {
      try {
        if (await authorize(principal, action) !== true) return failure('This action is not permitted.');
        const value = action.outputSchema.parse(await action.run(args, { principal }));
        const content = [{ type: 'text', text: JSON.stringify(value) }];
        if (action.content) content.push(...await action.content(value));
        return { content, structuredContent: value };
      } catch {
        return failure('The product could not complete this action.');
      }
    });
  }
  return server;
}
