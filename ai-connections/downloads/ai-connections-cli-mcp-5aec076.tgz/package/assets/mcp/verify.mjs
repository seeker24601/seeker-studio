import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { createHttpApp } from './http.mjs';

const client = new Client({ name: 'product-mcp-verification', version: '1' });
try {
  await client.connect(new StdioClientTransport({ command: process.execPath, args: [fileURLToPath(new URL('./stdio.mjs', import.meta.url))] }));
  assert.ok((await client.listTools()).tools.some(tool => tool.name === 'product_status'));
  const status = await client.callTool({ name: 'product_status', arguments: {} });
  assert.equal(status.isError, undefined);
  assert.equal(typeof status.structuredContent.ready, 'boolean');
} finally { await client.close(); }

const listener = await new Promise(resolve => {
  const server = createHttpApp().listen(0, '127.0.0.1', () => resolve(server));
});
try {
  const url = `http://127.0.0.1:${listener.address().port}/mcp`;
  assert.equal((await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).status, 401);
  assert.equal((await fetch(url, { method: 'POST', headers: { Origin: 'https://example.com' } })).status, 403);
} finally {
  listener.closeIdleConnections();
  await new Promise(resolve => listener.close(resolve));
}
process.stdout.write('MCP verification passed. Product action and account-isolation tests remain product-owned.\n');
