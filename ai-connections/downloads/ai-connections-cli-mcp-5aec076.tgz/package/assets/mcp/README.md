# Product MCP server

This folder connects desktop agents to your product's actions through MCP.

## Run

```sh
npm install
npm run verify
```

Merge an example from `clients/` into your agent's configuration. The examples
use absolute paths to Node and `stdio.mjs`. Regenerate them after moving the
project. They support Claude Desktop, Claude Code, Cursor, Codex, and Hermes.
The installer leaves existing files unchanged, so update preserved paths by hand.

The starter exposes `product_status` and reports `ready: false` until you wire
it to your product. `npm start` runs stdio. Clients launch Node directly so
package-manager output stays out of the protocol stream.

## Product actions

Define actions in `actions.mjs` with input/output schemas, an application
permission, MCP annotations, and a `run` handler. Resolve ownership from the
verified `principal` supplied to the handler. Keep credentials in the product.
Return only public output fields. Exceptions return a generic tool error.

Call existing product services from each handler. For generation, queue work
in the product and return a job ID. Add status and output actions for that job.
Reuse the product's limits, gallery, reference validation, and reported costs.
Do not automatically retry a request that may already have spent credits.
An optional `content(value)` formatter adds native MCP image or resource blocks
from the validated public result. It can read an approved gallery file path
returned by the action, keeping image bytes out of the JSON metadata.

The starter local principal can read product status. Add permissions in
`access.mjs` when you implement actions. Mark spending and deletion tools
`readOnlyHint: false`, `destructiveHint: true`, and `idempotentHint: false`.
Set `openWorldHint` to match whether the action contacts external services.
Keep the agent's approval controls enabled for spending and deletion.

Bind a stdio bridge to one product instance and data directory. Reconnect to
that instance after a restart. A stopped app must produce an error rather than
redirecting a write to another gallery or account.

## HTTP

```sh
npm run http
```

The endpoint is `http://127.0.0.1:4318/mcp`. Set `PRODUCT_MCP_PORT` to choose
another port. HTTP requests receive 401 until `authenticateHttp` in
`access.mjs` verifies the product's server session or access token and returns
`{ ownerId, permissions }`. Never derive ownership from tool arguments or an
unverified client-supplied owner header.

Authentication runs on every request. Each request gets a separate MCP server
with that identity. `authorize` checks the action's permission before its handler.
Examples for HTTP-capable clients are under `clients/http/`. Supply credentials
through the client's secret settings, using the product's authentication flow.

`createHttpApp` can mount behind the product's HTTPS and authentication stack.
Configure exact `allowedOrigins` for browser clients and `allowedHosts` for a
public host. The standalone command binds to loopback. It implements stateless
Streamable HTTP with JSON responses, without persistent notification streams.
Allowed browser origins receive credentialed CORS headers and unauthenticated
OPTIONS preflight responses. POST requests still require authentication.
JSON bodies are limited to 1 MiB. Oversized bodies return 413; malformed JSON
returns 400 and unsupported content encodings return 415, with generic messages.

## Verify the integration

Run `npm run verify` after changes. Add product tests for successful actions,
invalid inputs, failed permissions, owner isolation, credential redaction,
duplicate requests, job recovery, and missing references before generation.
Use fixture providers until live calls and their cost are authorized.

The scaffold installs no provider client or job queue. Use the product's
existing AI Connections integration for provider calls.
