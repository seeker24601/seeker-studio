import { readFileSync } from 'node:fs';
import { z } from 'zod';

export const product = JSON.parse(readFileSync(new URL('./product.json', import.meta.url), 'utf8'));

// Add product actions here. Each handler calls the product's existing services.
export const actions = [{
  name: 'product_status',
  description: 'Read whether the product integration is ready.',
  permission: 'product:read',
  inputSchema: z.object({}).strict(),
  outputSchema: z.object({ name: z.string(), ready: z.boolean() }).strict(),
  annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
  async run(args, { principal }) {
    return { name: product.name, ready: false };
  },
}];
