import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { createServer } from './server.mjs';
import { localPrincipal } from './access.mjs';

const server = createServer(await localPrincipal());
await server.connect(new StdioServerTransport());
process.stdin.once('end', () => { void server.close(); });
