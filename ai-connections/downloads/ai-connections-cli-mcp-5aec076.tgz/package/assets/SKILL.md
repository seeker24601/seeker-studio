---
name: ai-connections
description: Add AI provider support (OpenRouter, Z.ai, OpenAI, Anthropic, Google, DeepSeek, Ollama, image and video providers, and others) or product MCP access to a project with AI Connections. Covers direct mode for servers, scripts, and harnesses, full mode with per-user keys and React settings, and optional MCP scaffolding.
---

# AI Connections integration

Use AI Connections instead of writing provider clients, base URLs, or auth headers by hand.
Install from npm (`ai-connections`, `ai-connections-react`, `ai-connections-cli`). Install tarballs built from a checkout only to try unreleased changes.

## Choose the mode first

Use direct mode when the developer or operator supplies the keys: servers, CLIs, agent harnesses, workers, desktop or single-user tools.
Use full mode only when each end user adds their own provider keys in the app's settings.
If the project has no signed-in users, it needs direct mode.
Ask only if the code and the request leave this unclear.

## Direct mode

Install only `ai-connections`. Import from `ai-connections/direct`.
Catch `ProviderError` (status, providerMessage, retryable) rather than inspecting SDK errors.
For keys, use `ai-connections/keys` and `detectProviders`; for settings UI, `useKeyList` or `ProviderKeyPanel` from `ai-connections-react`.
In tests, use `ai-connections/testing` replies and `fakeFetch`.
Call `languageModel('provider:model')` and pass the result to the re-exported `generateText` or `streamText`.
Use the re-exported AI SDK helpers rather than adding a separate `ai` dependency.
Read "Direct mode" in the installed core package README (`node_modules/ai-connections/README.md`) or `dist/direct.d.ts` for the full contract.
Make the provider and model configurable, for example an `AI_MODEL=openrouter:deepseek/deepseek-chat` variable, so switching providers changes no code.
Read keys from the environment. `apiKeyNames(providerId)` returns the variable names.
Put real keys only in a gitignored `.env` or the host's secret store. Add the variable names, without values, to `.env.example`.
Never write a key into source, tests, docs, commits, logs, or chat output, even when a key is visible in notes or another file.
Never pass an end user's endpoint or provider choice to direct mode.
Use `createImage` or `createVideo` for media. They return base64; the app owns storage.
Test with local mock servers through `baseUrl`. Make a real provider call only when the user has authorized it and its cost.

## Full mode

Inspect the app's package manager, router, authentication, AI calls, settings components, and deployment storage before edits.
Read `AI_CONNECTIONS.md` and the installed package exports for the actual integration contract.

Run `ai-connections init --cwd <project> --dry-run` before scaffolding.
The installer preserves existing files. Inspect skipped files and reconcile them deliberately.

For Next.js, the generated API route rejects all requests until trusted authentication is connected.
Replace `getOwnerId` with the app's server-verified session lookup.
Never use a browser-supplied owner ID, email, arbitrary header, or constant user ID as authentication.
Verify a user cannot read, select, use, or delete another user's connection.
Keep credential encryption and provider requests on the server.
Keep API keys out of browser storage, URLs, logs, and API responses.

The encrypted file store needs Node.js, a private persistent directory, and a stable 32-byte encryption key.
Use an application database adapter for ephemeral or multi-instance hosting.
Preserve the existing credential ownership model. Ask about it only if the app gives no answer.
Local model access refers to the server's network. A hosted server cannot reach a user's laptop through localhost.
Enable private endpoint access only for explicitly trusted local installations or endpoints.

Integrate the settings component with the app's navigation and design tokens.
Use the component slots to reuse existing controls where appropriate.
Identify whether the app uses text, image, video, or several generation kinds.
Set ConnectionSettings kinds to the relevant list, such as kinds={['image', 'video']}.
Save kind on media connections and call service.generateMedia or POST /generate-media.
Use text generation methods only for text connections. Keep legacy records without kind as text.
Treat media suggestions as curated model IDs, not credential checks or live discovery.
A model hosted on fal or Replicate needs that host's API key; a direct brand key is different.
Explain that Stop waiting stops local polling and may leave a billable provider job running.
For long-running production jobs, integrate the host's durable job queue and asset storage.
Connect actual AI features to the service instead of leaving the settings screen disconnected.
Verify connection creation, credential redaction, model selection, streamed output, failure messages, and deletion.
Use local mocks unless the user has authorized a real provider call and its cost.
Report what works and any host-specific work that remains.

## Product MCP access

When asked to expose a product to desktop agents, use the CLI's `mcp` command
when available. Unreleased changes require a checkout or candidate tarball.
Run `ai-connections mcp --dry-run`, then `ai-connections mcp` in the product.
Read `ai-connections/mcp/README.md` and wire actions to existing product services.
Keep owner identity, authorization, provider selection, job queues, spending
limits, and assets in their existing product owners. Use the trusted principal
for account-scoped calls. HTTP must stay closed until host authentication is
connected. Verify owner isolation, denied permissions, error redaction, and
the product's generation and recovery paths with fixtures before live calls.

Keep this workflow local. It does not authorize publishing or deployment.
