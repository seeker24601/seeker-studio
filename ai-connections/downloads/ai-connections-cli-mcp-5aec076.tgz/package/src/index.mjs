#!/usr/bin/env node
import { readFile, realpath, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { route, settings, portableServer, guide } from './templates.mjs';
import { stat, safeTarget } from './files.mjs';
import { mcp } from './mcp-install.mjs';
import { isEntry } from './entry.mjs';
export { mcp } from './mcp-install.mjs';
export { isEntry } from './entry.mjs';

export async function init({ cwd = process.cwd(), dryRun = false, agent = 'both' } = {}) {
  if (!['both', 'claude', 'codex'].includes(agent)) throw new Error('Agent must be both, claude, or codex.');
  const root = await realpath(cwd);
  const packageFile = await safeTarget(root, 'package.json');
  let manifest;
  try { manifest = JSON.parse(await readFile(packageFile, 'utf8')); }
  catch { throw new Error('Expected a readable, valid package.json in the project directory.'); }
  const dependencies = { ...manifest.dependencies, ...manifest.devDependencies };
  const stack = dependencies.next ? 'next' : dependencies.react ? 'react' : null;
  if (!stack) throw new Error('Supported projects require next or react in package.json.');
  const files = new Map();
  if (stack === 'next') {
    const srcApp = await safeTarget(root, 'src/app');
    const app = await safeTarget(root, 'app');
    const appRoot = (await stat(app))?.isDirectory() ? 'app' : (await stat(srcApp))?.isDirectory() ? 'src/app' : null;
    if (!appRoot) throw new Error('Next.js requires an existing app/ or src/app/ directory. Pages Router needs manual integration.');
    files.set(`${appRoot}/api/ai-connections/[[...path]]/route.ts`, route);
    files.set(`${appRoot}/settings/ai-connections/page.tsx`, settings);
  } else {
    files.set('ai-connections/Settings.tsx', settings);
    files.set('ai-connections/server.ts', portableServer);
  }
  files.set('ai-connections.config.json', JSON.stringify({ version: 1, framework: stack, endpoint: '/api/ai-connections', storage: 'encrypted-file', authentication: 'host-integration-required' }, null, 2) + '\n');
  files.set('AI_CONNECTIONS.md', guide(stack));
  const skill = await readFile(new URL('../assets/SKILL.md', import.meta.url), 'utf8');
  if (agent !== 'codex') files.set('.claude/skills/ai-connections/SKILL.md', skill);
  if (agent !== 'claude') files.set('.agents/skills/ai-connections/SKILL.md', skill);
  const plan = [];
  for (const [relative, content] of files) {
    const target = await safeTarget(root, relative);
    const existing = await stat(target);
    if (existing && !existing.isFile()) throw new Error(`Expected regular file: ${target}`);
    plan.push({ path: relative, target, content, action: existing ? 'preserve' : 'create' });
  }
  for (const [relative, additions] of [
    ['.env.example', ['AI_CONNECTIONS_ENCRYPTION_KEY=', 'AI_CONNECTIONS_DATA_DIR=.ai-connections-data']],
    ['.gitignore', ['.ai-connections-data/']],
  ]) {
    const target = await safeTarget(root, relative);
    const existing = await stat(target);
    if (existing && !existing.isFile()) throw new Error(`Expected regular file: ${target}`);
    const before = existing ? await readFile(target, 'utf8') : '';
    const missing = additions.filter(line => {
      const key = line.split('=')[0];
      return !before.split(/\r?\n/).some(existingLine => relative === '.env.example'
        ? existingLine.trim().startsWith(key + '=')
        : existingLine.trim() === line);
    });
    const suffix = (before && !before.endsWith('\n') ? '\n' : '') + missing.join('\n') + (missing.length ? '\n' : '');
    plan.push({ path: relative, target, content: before + suffix, action: !missing.length ? 'preserve' : existing ? 'append' : 'create' });
  }
  if (!dryRun) {
    for (const item of plan) {
      if (item.action === 'preserve') continue;
      await safeTarget(root, item.path);
      await mkdir(path.dirname(item.target), { recursive: true });
      if (item.action === 'create') await writeFile(item.target, item.content, { flag: 'wx' });
      else {
        // Append only missing lines and preserve the user's existing content.
        const before = await readFile(item.target, 'utf8');
        if (!item.content.startsWith(before)) throw new Error(`File changed during installation: ${item.path}`);
        await writeFile(item.target, item.content.slice(before.length), { flag: 'a' });
      }
    }
  }
  return { root, stack, dryRun, files: plan.map(({ path, action }) => ({ path, action })) };
}

/**
 * Installs only the agent skill, in any project: Claude Code reads
 * .claude/skills, Codex reads .agents/skills. Every later agent session in the
 * project then knows to use AI Connections instead of writing a provider
 * client. An existing skill that differs is left alone unless `update` is set,
 * since it may have been edited for this project.
 */
export async function skill({ cwd = process.cwd(), dryRun = false, agent = 'both', update = false } = {}) {
  if (!['both', 'claude', 'codex'].includes(agent)) throw new Error('Agent must be both, claude, or codex.');
  const root = await realpath(cwd);
  const content = await readFile(new URL('../assets/SKILL.md', import.meta.url), 'utf8');
  const paths = [];
  if (agent !== 'codex') paths.push('.claude/skills/ai-connections/SKILL.md');
  if (agent !== 'claude') paths.push('.agents/skills/ai-connections/SKILL.md');
  const files = [];
  for (const relative of paths) {
    const target = await safeTarget(root, relative);
    const existing = await stat(target);
    if (existing && !existing.isFile()) throw new Error(`Expected regular file: ${target}`);
    const before = existing ? await readFile(target, 'utf8') : null;
    const action = before === null ? 'create' : before === content ? 'current' : update ? 'update' : 'differs';
    if (!dryRun && (action === 'create' || action === 'update')) {
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, content, action === 'create' ? { flag: 'wx' } : {});
    }
    files.push({ path: relative, action });
  }
  return { root, dryRun, files };
}

function parse(args, flags) {
  const options = {};
  while (args.length) {
    const flag = args.shift();
    if (flag === '--dry-run') options.dryRun = true;
    else if (flag === '--update' && flags.includes('--update')) options.update = true;
    else if (flag === '--cwd' || flag === '--agent') {
      const value = args.shift();
      if (!value || value.startsWith('--')) throw new Error(`Missing value for ${flag}`);
      options[flag === '--cwd' ? 'cwd' : 'agent'] = value;
    } else throw new Error(`Unknown option: ${flag}`);
  }
  return options;
}

async function main(args) {
  if (!args.length || args.includes('--help') || args.includes('-h')) {
    console.log([
      'ai-connections skill [--cwd PATH] [--agent both|claude|codex] [--update] [--dry-run]',
      '  Install the AI Connections skill for Claude Code and Codex in any project.',
      'ai-connections init [--cwd PATH] [--agent both|claude|codex] [--dry-run]',
      '  Scaffold full mode (per-user keys, settings screen) into a Next.js or React app.',
      'ai-connections mcp [--cwd PATH] [--dry-run]',
      '  Add an MCP server and client configuration examples to a product.',
    ].join('\n'));
    return;
  }
  const command = args.shift();
  if (command === 'mcp') {
    const options = parse(args, []);
    if (options.agent) throw new Error('The mcp command creates configuration examples for all supported clients.');
    const result = await mcp(options);
    console.log(`${result.dryRun ? 'Dry run' : 'Setup'}: product MCP at ${result.root}`);
    for (const file of result.files) console.log(`${file.action.padEnd(8)} ${file.path}`);
    console.log('Setup: ai-connections/mcp/README.md');
    return;
  }
  if (command === 'skill') {
    const result = await skill(parse(args, ['--update']));
    for (const file of result.files) console.log(`${file.action.padEnd(8)} ${file.path}`);
    if (result.files.some((f) => f.action === 'differs')) console.log('A skill there differs from this version; rerun with --update to replace it.');
    console.log('Next: ask your agent to add AI provider support. It will use the ai-connections skill.');
    return;
  }
  if (command !== 'init') throw new Error('Expected command: skill, init, or mcp');
  const result = await init(parse(args, []));
  console.log(`${result.dryRun ? 'Dry run' : 'Setup'}: ${result.stack} at ${result.root}`);
  for (const file of result.files) console.log(`${file.action.padEnd(8)} ${file.path}`);
  console.log('Next: npm install ai-connections ai-connections-react, then complete authentication and AI feature wiring in AI_CONNECTIONS.md.');
}

if (await isEntry(process.argv[1], import.meta.url)) {
  main(process.argv.slice(2)).catch(error => { console.error(error.message); process.exitCode = 1; });
}
