import { realpath } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

// Resolve both paths so linked launchers and redirected folders agree.
export async function isEntry(argvPath, moduleUrl, resolve = realpath) {
  if (!argvPath) return false;
  try { return await resolve(argvPath) === await resolve(fileURLToPath(moduleUrl)); }
  catch { return false; }
}
