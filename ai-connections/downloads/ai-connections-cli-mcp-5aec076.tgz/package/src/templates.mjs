export const route = `import { createConnections, encryptedFileStore, createConnectionHandler } from 'ai-connections';

export const runtime = 'nodejs';
let handler: ReturnType<typeof createConnectionHandler> | undefined;

async function handle(request: Request) {
  if (!handler) {
    const encryptionKey = process.env.AI_CONNECTIONS_ENCRYPTION_KEY;
    if (!encryptionKey) return Response.json({ error: 'AI Connections needs server configuration.' }, { status: 503 });
    const service = createConnections({
      store: encryptedFileStore({ directory: process.env.AI_CONNECTIONS_DATA_DIR ?? '.ai-connections-data', encryptionKey }),
    });
    handler = createConnectionHandler({
      service,
      basePath: '/api/ai-connections',
      getOwnerId: async (_request: Request): Promise<string | null> => {
        // Replace with your server-verified session lookup. Null rejects unauthenticated requests.
        return null;
      },
    });
  }
  return handler(request);
}

export { handle as GET, handle as POST, handle as DELETE, handle as PUT };
`;

export const settings = `'use client';
import { ConnectionSettings } from 'ai-connections-react';
import 'ai-connections-react/styles.css';

export default function AIConnectionSettings() {
  return <ConnectionSettings endpoint="/api/ai-connections" />;
}
`;

export const portableServer = `import { createConnections, encryptedFileStore, createConnectionHandler } from 'ai-connections';

// Run only on your Node server. Supply the app's trusted authentication callback.
export function createAIConnectionHandler(getOwnerId: (request: Request) => Promise<string | null>) {
  const encryptionKey = process.env.AI_CONNECTIONS_ENCRYPTION_KEY;
  if (!encryptionKey) throw new Error('Set AI_CONNECTIONS_ENCRYPTION_KEY on the server.');
  const service = createConnections({
    store: encryptedFileStore({ directory: process.env.AI_CONNECTIONS_DATA_DIR ?? '.ai-connections-data', encryptionKey }),
  });
  return createConnectionHandler({ service, getOwnerId, basePath: '/api/ai-connections' });
}
`;

export function guide(stack) {
  return `# AI Connections integration

The installer generated ${stack === 'next' ? 'Next.js App Router routes' : 'React client and Node server examples'}.
Existing files were preserved. Review the installer's skipped-file list.

## Install packages

From this project, run:

\`\`\`sh
npm install ai-connections ai-connections-react
\`\`\`

To try unreleased changes, install tarballs built from a checkout (\`npm run pack:all\`) by absolute path instead.

Use your app's package manager if it differs. React must already be installed.

## Server configuration

Generate an encryption key:

\`\`\`sh
node -e "console.log(require('node:crypto').randomBytes(32).toString('base64'))"
\`\`\`

Store the result in AI_CONNECTIONS_ENCRYPTION_KEY through your server's secret configuration.
Never prefix this variable with NEXT_PUBLIC_ or VITE_.
Keep the key stable. Replacing it makes existing credentials unreadable.
Set AI_CONNECTIONS_DATA_DIR to a private persistent directory outside public assets.
The default .ai-connections-data directory is added to .gitignore.
This file store supports a single Node host. Use a database-backed store for ephemeral or multi-instance servers.

## Connect the app

${stack === 'next' ? 'Replace the generated route\'s getOwnerId callback with your server-verified session lookup. It currently returns null and rejects every request.' : 'Mount the Node handler at /api/ai-connections and /api/ai-connections/* on your existing server. Supply trusted server authentication. Vite alone does not provide this server.'}
Never trust a user ID supplied by the browser.
Use same-origin requests. For cross-origin access, configure allowedOrigins and implement CORS responses in the host server.
Add the settings component to your navigation and adapt its styling to your app.
Set ConnectionSettings kinds to ['image'], ['video'], or the app's relevant combination.
Media connections save kind and use POST /generate-media; text uses POST /generate.
Media model suggestions do not verify credentials. A generation request may incur charges.
Video calls wait for provider completion; production hosts need sufficient request timeouts or durable background jobs.
Stopping the client wait may leave a provider job running.
Wire the actual AI features to the core service. Settings alone do not change existing AI calls.
Keep provider keys and provider calls on the server.

Local runtimes must be reachable from that server. A hosted server's localhost is not the user's computer.
Private endpoints require an explicit trusted network policy.

## Verify

Check that unauthenticated requests fail and users cannot access each other's connections.
Create a connection, select a model, use it in an AI feature, and delete it.
Check that API responses and browser storage contain no credentials.
Use local mocks before any authorized, potentially billable provider checks.

Both coding agents can use the installed ai-connections skill to complete app-specific integration.
`;
}
