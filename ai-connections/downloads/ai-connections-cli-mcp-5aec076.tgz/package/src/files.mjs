import { lstat } from 'node:fs/promises';
import path from 'node:path';

export async function stat(file) {
  try { return await lstat(file); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}

export async function safeTarget(root, relative) {
  const target = path.resolve(root, relative);
  if (!target.startsWith(root + path.sep)) throw new Error(`Path escapes project: ${relative}`);
  let current = root;
  for (const piece of relative.split('/')) {
    current = path.join(current, piece);
    const entry = await stat(current);
    if (entry?.isSymbolicLink()) throw new Error(`Refusing symbolic link: ${current}`);
    if (current !== target && entry && !entry.isDirectory()) throw new Error(`Expected directory: ${current}`);
  }
  return target;
}
