import { readFile, realpath, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { safeTarget, stat } from './files.mjs';

const folder = 'ai-connections/mcp';
const json = value => JSON.stringify(value, null, 2) + '\n';

export async function mcp({ cwd = process.cwd(), dryRun = false } = {}) {
  const root = await realpath(cwd);
  const manifestPath = await safeTarget(root, 'package.json');
  let manifest;
  try { manifest = JSON.parse(await readFile(manifestPath, 'utf8')); }
  catch { throw new Error('Expected a readable, valid package.json in the project directory.'); }
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) throw new Error('Expected a package.json object.');
  const name = typeof manifest.name === 'string'
    ? manifest.name.replace(/[^a-zA-Z0-9_.-]/g, '-').slice(0, 64) || 'product'
    : 'product';
  const files = new Map();
  for (const file of ['server.mjs', 'actions.mjs', 'access.mjs', 'stdio.mjs', 'http.mjs', 'verify.mjs', 'README.md']) {
    files.set(`${folder}/${file}`, await readFile(new URL(`../assets/mcp/${file}`, import.meta.url), 'utf8'));
  }
  files.set(`${folder}/entry.mjs`, await readFile(new URL('./entry.mjs', import.meta.url), 'utf8'));
  files.set(`${folder}/package.json`, json({
    name: `${name.toLowerCase()}-mcp`, private: true, type: 'module', version: '0.0.0',
    scripts: { start: 'node stdio.mjs', http: 'node http.mjs', verify: 'node verify.mjs' },
    engines: { node: '>=22' }, dependencies: { '@modelcontextprotocol/sdk': '^1.32.2', cors: '^2.8.6', express: '^4.22.1', zod: '^4.0.0' },
  }));
  files.set(`${folder}/product.json`, json({ name, version: '0.0.0' }));
  files.set(`${folder}/.gitignore`, 'node_modules/\n.env\n');
  const command = process.execPath;
  const args = [path.join(root, folder, 'stdio.mjs')];
  const local = { command, args };
  for (const client of ['claude-desktop', 'claude-code', 'cursor']) {
    files.set(`${folder}/clients/${client}.json`, json({ mcpServers: { [name]: local } }));
  }
  files.set(`${folder}/clients/codex.toml`, `[mcp_servers.${JSON.stringify(name)}]\ncommand = ${JSON.stringify(command)}\nargs = ${JSON.stringify(args)}\n`);
  files.set(`${folder}/clients/hermes.yaml`, `mcp_servers:\n  ${JSON.stringify(name)}:\n    command: ${JSON.stringify(command)}\n    args: ${JSON.stringify(args)}\n`);
  const url = 'http://127.0.0.1:4318/mcp';
  files.set(`${folder}/clients/http/claude-code.json`, json({ mcpServers: { [name]: { type: 'http', url } } }));
  files.set(`${folder}/clients/http/cursor.json`, json({ mcpServers: { [name]: { url } } }));
  files.set(`${folder}/clients/http/codex.toml`, `[mcp_servers.${JSON.stringify(name)}]\nurl = ${JSON.stringify(url)}\n`);
  files.set(`${folder}/clients/http/hermes.yaml`, `mcp_servers:\n  ${JSON.stringify(name)}:\n    url: ${JSON.stringify(url)}\n`);
  const plan = [];
  for (const [relative, content] of files) {
    const target = await safeTarget(root, relative);
    const existing = await stat(target);
    if (existing && !existing.isFile()) throw new Error(`Expected regular file: ${target}`);
    plan.push({ path: relative, target, content, action: existing ? 'preserve' : 'create' });
  }
  if (!dryRun) {
    for (const file of plan) {
      if (file.action === 'preserve') continue;
      await safeTarget(root, file.path);
      await mkdir(path.dirname(file.target), { recursive: true });
      await writeFile(file.target, file.content, { flag: 'wx' });
    }
  }
  return { root, dryRun, files: plan.map(({ path, action }) => ({ path, action })) };
}
